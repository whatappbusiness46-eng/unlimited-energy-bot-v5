# ============================================================
# config.py
# Unlimited Energy Bot V2
# FINAL CENTRAL CONFIGURATION
# ============================================================

import os


# ============================================================
# BOT
# ============================================================

BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    raise RuntimeError(
        "BOT_TOKEN environment variable is not configured."
    )


BOT_NAME = "Unlimited Energy Bot"
BOT_VERSION = "V2.1-FINAL"


# ============================================================
# DATABASE
# ============================================================

MONGO_URI = os.getenv("MONGO_URI")

if not MONGO_URI:
    raise RuntimeError(
        "MONGO_URI environment variable is not configured."
    )

DATABASE_NAME = os.getenv(
    "DATABASE_NAME",
    "UnlimitedEnergy",
)

COLLECTION_NAME = "users"


# ============================================================
# ADMIN
# ============================================================

# Recommended:
# Set ADMIN_ID in Render Environment Variables.
#
# Example:
# ADMIN_ID=7713476833

try:
    ADMIN_ID = int(
        os.getenv(
            "ADMIN_ID",
            "7713476833",
        )
    )
except ValueError:
    raise RuntimeError(
        "ADMIN_ID must be a valid Telegram user ID."
    )


# ============================================================
# FORCE JOIN
# ============================================================

FORCE_JOIN_ENABLED = os.getenv("FORCE_JOIN_ENABLED", "true").strip().lower() in {"1", "true", "yes", "on"}


GROUPS = [
    "@UnlimitedEnergyTasks",
    "@UnlimitedEnergyRewards",
    "@UnlimitedEnergyCommunity",
    "@UnlimitedEnergyOfficial",
]


# Reward for successfully completing force join.
GROUP_JOIN_REWARD = 20

# Provider member rewards are independent of provider payout.
CPAGRIP_DEFAULT_USER_REWARD_POINTS = max(1, int(os.getenv("CPAGRIP_DEFAULT_USER_REWARD_POINTS", "200")))
CPAGRIP_OFFER_LIMIT = max(1, int(os.getenv("CPAGRIP_OFFER_LIMIT", "5")))


# ============================================================
# WITHDRAW
# ============================================================

MIN_WITHDRAW = 1000
# IMPORTANT:
# Replace these placeholders with your real payment details
# through Render Environment Variables.

BKASH_NUMBER = os.getenv(
    "BKASH_NUMBER",
    "017XXXXXXXX",
)

NAGAD_NUMBER = os.getenv(
    "NAGAD_NUMBER",
    "018XXXXXXXX",
)

BYBIT_UID = os.getenv(
    "BYBIT_UID",
    "YOUR_BYBIT_UID",
)

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "")

PREMIUM_CASH_PRICE = float(os.getenv("PREMIUM_CASH_PRICE", "199"))
PREMIUM_MULTIPLIER = float(os.getenv("PREMIUM_MULTIPLIER", "2.0"))
VIP1_CASH_PRICE = float(os.getenv("VIP1_CASH_PRICE", "299"))
VIP2_CASH_PRICE = float(os.getenv("VIP2_CASH_PRICE", "499"))
VIP3_CASH_PRICE = float(os.getenv("VIP3_CASH_PRICE", "799"))
VIP4_CASH_PRICE = float(os.getenv("VIP4_CASH_PRICE", "1199"))
VIP5_CASH_PRICE = float(os.getenv("VIP5_CASH_PRICE", "1799"))


# ============================================================
# WITHDRAW STATUS
# ============================================================

WITHDRAW_PENDING = "pending"
WITHDRAW_APPROVED = "approved"
WITHDRAW_REJECTED = "rejected"


# ============================================================
# DAILY BONUS
# ============================================================

DAILY_BONUS = 5
DAILY_XP = 5

# Day 7 special reward.
DAY7_BONUS = 25

# Maximum normal streak display/tracking limit.
MAX_DAILY_STREAK = 7


# ============================================================
# DAILY TASKS
# ============================================================

MAX_DAILY_TASKS = 5

TASK_REWARD_MIN = 5
TASK_REWARD_MAX = 50

TASK_XP = 5
TASK_ENERGY_COST = 1


# ============================================================
# OFFERS
# ============================================================

OFFER_REWARD_MIN = 10
OFFER_REWARD_MAX = 100

OFFER_XP = 10


# ============================================================
# SHORTLINK
# ============================================================

SHORTLINK_REWARD_MIN = 5
SHORTLINK_REWARD_MAX = 50

SHORTLINK_XP = 10


# ============================================================
# FLASH JOIN BONUS / ACTIVE MEMBER CAMPAIGN
# ============================================================
# Join bonus is credited as Points using the existing withdrawal rate.
# Default conversion: 10 Points = ৳1, so 50৳ = 500 Points.
JOIN_BONUS_ENABLED = os.getenv("JOIN_BONUS_ENABLED", "true").strip().lower() in {"1", "true", "yes", "on"}
JOIN_BONUS_POINTS_PER_BDT = max(1, int(os.getenv("JOIN_BONUS_POINTS_PER_BDT", "10")))
# Join Bonus is lifetime-open; retained for backward compatibility with older deployments.
# The claim logic no longer applies a duration/end-time cutoff.
JOIN_BONUS_DURATION_SECONDS = 0
JOIN_BONUS_FIRST_TIER_COUNT = max(0, int(os.getenv("JOIN_BONUS_FIRST_TIER_COUNT", "100")))
JOIN_BONUS_FIRST_TIER_BDT = max(0, int(os.getenv("JOIN_BONUS_FIRST_TIER_BDT", "50")))
JOIN_BONUS_SECOND_TIER_COUNT = max(0, int(os.getenv("JOIN_BONUS_SECOND_TIER_COUNT", "250")))
JOIN_BONUS_SECOND_TIER_BDT = max(0, int(os.getenv("JOIN_BONUS_SECOND_TIER_BDT", "20")))
JOIN_BONUS_THIRD_TIER_COUNT = max(0, int(os.getenv("JOIN_BONUS_THIRD_TIER_COUNT", "500")))
JOIN_BONUS_THIRD_TIER_BDT = max(0, int(os.getenv("JOIN_BONUS_THIRD_TIER_BDT", "5")))
JOIN_BONUS_CAMPAIGN_START_AT = os.getenv("JOIN_BONUS_CAMPAIGN_START_AT", "").strip()

ACTIVE_CAMPAIGN_DAYS = max(1, int(os.getenv("ACTIVE_CAMPAIGN_DAYS", "7")))
ACTIVE_CAMPAIGN_TASK_SCORE = max(1, int(os.getenv("ACTIVE_CAMPAIGN_TASK_SCORE", "1")))
ACTIVE_CAMPAIGN_REFERRAL_SCORE = max(1, int(os.getenv("ACTIVE_CAMPAIGN_REFERRAL_SCORE", "5")))


# ============================================================
# REFERRAL
# ============================================================

REFERRAL_REWARD = 10
REFERRAL_XP = 10

MAX_REFERRAL_REWARD_PER_USER = 1000


# ============================================================
# ENERGY
# ============================================================

MAX_ENERGY = 100

# One energy every 300 seconds.
ENERGY_REGEN_SECONDS = 300


# ============================================================
# SPIN WHEEL
# ============================================================

SPIN_MIN = 1
SPIN_MAX = 20

SPIN_TICKET_REWARD = 1

# 0 means no cooldown.
SPIN_COOLDOWN = 0


# ============================================================
# LUCKY BOX
# ============================================================

LUCKYBOX_MIN = 5
LUCKYBOX_MAX = 30

LUCKYBOX_TICKET_REWARD = 1

LUCKYBOX_COOLDOWN = 0


# ============================================================
# SCRATCH CARD
# ============================================================

SCRATCH_MIN = 2
SCRATCH_MAX = 15

SCRATCH_CARD_REWARD = 1

SCRATCH_COOLDOWN = 0


# ============================================================
# JACKPOT
# ============================================================

JACKPOT_MIN = 10
JACKPOT_MAX = 100

JACKPOT_TICKET_REWARD = 1

JACKPOT_COOLDOWN = 0


# ============================================================
# PREMIUM
# ============================================================

PREMIUM_PRICE = 199
PREMIUM_DAYS = 30

FIRST_PREMIUM_WINNERS = 5


# ============================================================
# VIP
# ============================================================

VIP_PRICE = 499
VIP_DAYS = 30


# ============================================================
# XP / LEVEL
# ============================================================

XP_PER_LEVEL = 100


# ============================================================
# RANK REQUIREMENTS
# ============================================================

BRONZE_REQUIRED = 600
SILVER_REQUIRED = 2000
GOLD_REQUIRED = 6000
DIAMOND_REQUIRED = 10000


# ============================================================
# GAME / REWARD SECURITY
# ============================================================

# Prevent impossible negative rewards.
MIN_REWARD = 0

# Maximum reward that one individual game/action can give.
MAX_SINGLE_REWARD = 1000


# ============================================================
# NOTIFICATIONS
# ============================================================

ENABLE_NOTIFICATIONS = True


# ============================================================
# LEADERBOARD / ACTIVITY
# ============================================================

LEADERBOARD_LIMIT = 10
ACTIVITY_LIMIT = 10


# ============================================================
# PAGINATION
# ============================================================

PAGE_SIZE = 10


# ============================================================
# CALLBACK SECURITY
# ============================================================

MAX_CALLBACK_DATA_LENGTH = 64


# ============================================================
# BOT FEATURES
# ============================================================

FEATURES = {
    "daily_bonus": True,
    "daily_tasks": True,
    "offers": True,
    "shortlinks": True,
    "spin": True,
    "lucky_box": True,
    "scratch_card": True,
    "jackpot": True,
    "referral": True,
    "withdraw": True,
    "premium": True,
    "vip": True,
    "leaderboard": True,
    "activity": True,
    "statistics": True,
    "force_join": True,
}


# ============================================================
# DEFAULT USER VALUES
# ============================================================

DEFAULT_USER_VALUES = {
    "balance": 0,
    "xp": 0,
    "level": 1,
    "energy": MAX_ENERGY,
    "daily_streak": 0,
    "daily_task_count": 0,
    "referrals": 0,
    "spin_tickets": 0,
    "luckybox_tickets": 0,
    "scratch_tickets": 0,
    "jackpot_tickets": 0,
    "banned": False,
    "blacklisted": False,
}


# ============================================================
# LOGGING / DEBUG
# ============================================================

DEBUG_MODE = (
    os.getenv(
        "DEBUG_MODE",
        "false",
    ).lower()
    == "true"
)


# ============================================================
# TIMEZONE
# ============================================================

TIMEZONE = os.getenv(
    "TIMEZONE",
    "Asia/Dhaka",
)


# ============================================================
# ENVIRONMENT
# ============================================================

ENVIRONMENT = os.getenv(
    "ENVIRONMENT",
    "production",
)




# ============================================================
# PROVIDER INTEGRATIONS
# ============================================================

PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
REWARD_POINTS_PER_USD = int(os.getenv("REWARD_POINTS_PER_USD", "1000"))

# CPAGrip
CPAGRIP_ENABLED = os.getenv("CPAGRIP_ENABLED", "true").lower() in {"1", "true", "yes", "on"}
CPAGRIP_API_KEY = os.getenv("CPAGRIP_API_KEY", "")
CPAGRIP_OFFERS_API_URL = os.getenv("CPAGRIP_OFFERS_API_URL", "")
CPAGRIP_POSTBACK_PASSWORD = os.getenv("CPAGRIP_POSTBACK_PASSWORD", os.getenv("CPAGRIP_POSTBACK_SECRET", ""))

# Manual shortlinks and Offerwall.me shortlinks are supported.
# Legacy shortener integrations have been removed.
CONFIG_READY = True

CPAGRIP_USER_REWARD_PERCENT = float(os.getenv("CPAGRIP_USER_REWARD_PERCENT", "40"))

# Offerwall.me publisher postback integration.
# The private secret must stay server-side in Render Environment Variables.
OFFERWALLME_ENABLED = os.getenv("OFFERWALLME_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
OFFERWALLME_POSTBACK_SECRET = os.getenv("OFFERWALLME_POSTBACK_SECRET", "").strip()
OFFERWALLME_USER_REWARD_PERCENT = float(os.getenv("OFFERWALLME_USER_REWARD_PERCENT", "40"))
OFFERWALLME_POINTS_PER_USD = float(os.getenv("OFFERWALLME_POINTS_PER_USD", "1000"))
# Offerwall.me `reward` is normally reported in the placement currency.
# The current placement uses Points, with 200 Points = $1. Keep this configurable
# in case the publisher changes the placement currency/exchange rate later.
OFFERWALLME_REWARD_UNIT = os.getenv("OFFERWALLME_REWARD_UNIT", "points").strip().lower()
OFFERWALLME_CURRENCY_PER_USD = float(os.getenv("OFFERWALLME_CURRENCY_PER_USD", "200"))
OFFERWALLME_API_KEY = os.getenv("OFFERWALLME_API_KEY", "").strip()
OFFERWALLME_BEARER_TOKEN = os.getenv("OFFERWALLME_BEARER_TOKEN", "").strip()
OFFERWALLME_DEFAULT_IP = os.getenv("OFFERWALLME_DEFAULT_IP", "0.0.0.0").strip()
OFFERWALLME_COUNTRY = os.getenv("OFFERWALLME_COUNTRY", "BD").strip().upper()
# Maximum Offerwall.me live tasks/shortlinks shown in the bot.
OFFERWALLME_TASK_LIMIT = max(1, int(os.getenv("OFFERWALLME_TASK_LIMIT", "20")))
OFFERWALLME_SHORTLINK_LIMIT = max(1, int(os.getenv("OFFERWALLME_SHORTLINK_LIMIT", "20")))
