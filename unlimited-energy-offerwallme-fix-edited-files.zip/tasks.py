# ============================================================
# TASK SYSTEM - MongoDB backed, admin managed
# ============================================================
import asyncio
import logging
import os
import time
from urllib.parse import urlparse
from typing import Optional

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes
from pymongo.errors import DuplicateKeyError

from database import (
    db, users, get_user, update_user, add_balance, add_activity,
    get_membership_multiplier, use_energy, add_xp,
)
from config import ADMIN_ID, OFFERWALLME_TASK_LIMIT
from provider_integrations import (
    get_offerwallme_tasks, get_cached_offerwallme_tasks, provider_cache_fresh,
    refresh_offerwallme_tasks, submit_offerwallme_task_proof, _offerwallme_reward_points,
    create_offerwall_task_proof, get_offerwall_task_submission, mark_offerwall_task_submission,
    get_cpa_lead_bd_offers, get_cached_cpa_lead_bd_offers, refresh_cpa_lead_bd_offers,
    _cpa_lead_member_reward_points, _cpa_lead_offer_url, _record_provider_pending, _provider_task_hidden,
    _offerwallme_task_tracking_url, admin_test_provider_completion,
    get_offerwallme_hosted_url,
)

logger = logging.getLogger(__name__)
_BACKGROUND_REFRESHING = set()


def _md(value):
    """Escape Telegram Markdown v1 special characters in dynamic task content."""
    text = "" if value is None else str(value)
    return text.replace("\\", "\\\\").replace("*", "\\*").replace("_", "\\_").replace("`", "\\`").replace("[", "\\[")

tasks_collection = db["tasks"]
completions_collection = db["task_completions"]
TASK_COOLDOWN = 86400
DEFAULT_REWARD = 10
DEFAULT_XP = 5
DEFAULT_ENERGY = 1
DEFAULT_VERIFICATION = "telegram_join"
# Verification is disabled by default. Set TASK_VERIFICATION_ENABLED=true in Render to enable it.
TASK_VERIFICATION_ENABLED = os.getenv("TASK_VERIFICATION_ENABLED", "false").strip().lower() in {"1", "true", "yes", "on"}
# Private Telegram join tasks use this chat/channel ID (for example: -1001234567890).
# The bot must be an admin/member of that private channel to verify membership.
TASK_PRIVATE_CHAT_ID = os.getenv("TASK_PRIVATE_CHAT_ID", "").strip()

# Short per-user cache prevents the Task Center from fetching the same
# Offerwall.me task list twice during one screen render and reduces repeated
# provider calls when a user opens Tasks again shortly afterwards.
_OFFERWALL_TASK_CACHE = {}
_OFFERWALL_TASK_CACHE_TTL = 45


def _now():
    return int(time.time())


def _safe_int(v, d=0):
    try:
        return int(v)
    except (TypeError, ValueError):
        return d


def _ensure_named_index(collection, keys, *, unique=False, name=None):
    """Create an index without failing when MongoDB already has the same key pattern under another name."""
    desired = list(keys)
    indexes = collection.index_information()
    matching = []
    for existing_name, info in indexes.items():
        existing_keys = info.get("key")
        if existing_keys is not None and list(existing_keys) == desired:
            matching.append((existing_name, info))

    # A matching index with the required uniqueness is already sufficient.
    for existing_name, info in matching:
        if bool(info.get("unique", False)) == bool(unique):
            return existing_name

    # Same key pattern but wrong uniqueness: remove the conflicting index first.
    for existing_name, _info in matching:
        if existing_name != "_id_":
            collection.drop_index(existing_name)

    return collection.create_index(desired, unique=unique, name=name)


def ensure_task_indexes():
    try:
        _ensure_named_index(tasks_collection, [("id", 1)], unique=True, name="task_id_unique")
        _ensure_named_index(
            completions_collection,
            [("user_id", 1), ("task_id", 1)],
            unique=True,
            name="user_task_unique",
        )
        _ensure_named_index(
            completions_collection,
            [("user_id", 1), ("status", 1)],
            unique=False,
            name="user_status_idx",
        )
        _ensure_named_index(
            db["offerwall_task_submissions"],
            [("user_id", 1), ("task_id", 1)],
            unique=True,
            name="offerwall_task_submission_unique",
        )
        _ensure_named_index(
            db["offerwall_task_submissions"],
            [("user_id", 1), ("status", 1), ("submitted_at", -1)],
            unique=False,
            name="offerwall_task_submission_status",
        )
        return True
    except Exception:
        logger.exception("task index creation failed")
        return False


ensure_task_indexes()


def seed_default_task():
    # Create disabled task slots only; no fake links or automatic rewards.
    ensure_task_indexes()
    starter_tasks = [
        ("starter_task_01", "📣 Official Channel Task", "Replace URL with your real public Telegram channel.", "", "telegram_join"),
        ("starter_task_02", "🤖 Partner Bot Task", "Replace URL with your real partner bot/deep-link.", "", "manual"),
        ("starter_task_03", "📢 Sponsor Channel Task", "Replace URL with an approved sponsor channel.", "", "telegram_join"),
        ("starter_task_04", "🎯 Community Task", "Replace URL with your real community link.", "", "telegram_join"),
        ("starter_task_05", "⭐ VIP Task Slot", "Configure a real VIP task and keep it under Admin Approval.", "", "manual"),
        ("starter_task_06", "🎁 Promotion Task", "Configure a real promotional task.", "", "manual"),
        ("starter_task_07", "🚀 Partner Task", "Configure a real partner task with an approved destination.", "", "manual"),
        ("starter_task_08", "💎 VIP Partner Task", "Configure a real VIP partner task.", "", "manual"),
    ]
    for tid, title, desc, url, verify in starter_tasks:
        if not tasks_collection.find_one({"id": tid}, {"_id": 1}):
            register_task(tid, title, desc, reward=10, url=url or None, cooldown=0, enabled=False, xp=0, energy=0, task_type="starter", audience="normal", verification_method=verify)


def _normalise_verification(value, url=None):
    value = str(value or "").strip().lower()
    aliases = {"join": "telegram_join", "telegram": "telegram_join", "channel_join": "telegram_join"}
    value = aliases.get(value, value)
    if value not in {"telegram_join", "manual", "click_once"}:
        value = DEFAULT_VERIFICATION if url and "t.me/" in str(url) else "manual"
    return value


def register_task(task_id: str, title: str, description: str = "", reward: int = DEFAULT_REWARD,
                  url: Optional[str] = None, cooldown: int = TASK_COOLDOWN, enabled: bool = True,
                  xp: int = DEFAULT_XP, energy: int = DEFAULT_ENERGY,
                  task_type: str = "telegram", audience: str = "normal",
                  verification_method: str = DEFAULT_VERIFICATION) -> bool:
    task_id = str(task_id).strip()
    if not task_id or len(task_id) > 50:
        return False
    audience = str(audience or "normal").strip().lower()
    if audience not in {"normal", "vip", "both"}:
        return False
    verification_method = _normalise_verification(verification_method, url)
    doc = {
        "id": task_id,
        "title": str(title or task_id)[:120],
        "description": str(description or "")[:1000],
        "reward": max(0, _safe_int(reward)),
        "url": url,
        "cooldown": max(0, _safe_int(cooldown, TASK_COOLDOWN)),
        "enabled": bool(enabled),
        "xp": max(0, _safe_int(xp, DEFAULT_XP)),
        "energy": max(0, _safe_int(energy, DEFAULT_ENERGY)),
        "task_type": str(task_type or "telegram")[:40],
        "audience": audience,
        "verification_method": verification_method,
        "updated_at": _now(),
    }
    try:
        tasks_collection.update_one(
            {"id": task_id}, {"$set": doc, "$setOnInsert": {"created_at": _now()}}, upsert=True
        )
        return True
    except Exception:
        logger.exception("register task failed")
        return False


def get_tasks(include_disabled=False, user_id=None):
    q = {} if include_disabled else {"enabled": True}
    tasks = list(tasks_collection.find(q, {"_id": 0}).sort("created_at", 1))
    if user_id is None:
        return tasks
    vip = bool((db["users"].find_one({"user_id": int(user_id)}, {"vip": 1, "vip_expire": 1}) or {}).get("vip"))
    # Use the central VIP status helper when possible so expired VIP is not treated as active.
    try:
        from database import get_vip_status
        vip = bool(get_vip_status(user_id).get("active"))
    except Exception:
        pass
    return [t for t in tasks if t.get("audience", "normal") in ({"vip", "both"} if vip else {"normal", "both"})]


def get_task(task_id):
    return tasks_collection.find_one({"id": str(task_id)}, {"_id": 0})


def set_task_enabled(task_id, enabled):
    return tasks_collection.update_one({"id": str(task_id)}, {"$set": {"enabled": bool(enabled), "updated_at": _now()}}).modified_count > 0


def delete_task(task_id):
    return tasks_collection.delete_one({"id": str(task_id)}).deleted_count > 0


def _completed_map(user):
    value = user.get("task_history", {})
    return dict(value) if isinstance(value, dict) else {}


def _is_vip(user_id):
    try:
        from database import get_vip_status
        return bool(get_vip_status(user_id).get("active"))
    except Exception:
        return False


def task_visible(user_id, task):
    if not task or not task.get("enabled", True):
        return False
    audience = task.get("audience", "normal")
    return audience in ({"vip", "both"} if _is_vip(user_id) else {"normal", "both"})


def task_available(user_id, task_id):
    user = get_user(user_id, create=False)
    task = get_task(task_id)
    if not user or user.get("banned") or user.get("blacklisted") or not task_visible(user_id, task):
        return False
    # Permanent completion wins over all cooldown logic.
    completion = completions_collection.find_one({"user_id": int(user_id), "task_id": str(task_id)})
    if completion and completion.get("status") in {"rewarded", "pending"}:
        return False
    if str(task_id) in {str(x) for x in user.get("completed_tasks", [])}:
        return False
    last = _safe_int(_completed_map(user).get(str(task_id)), 0)
    return not last or _now() - last >= max(0, _safe_int(task.get("cooldown"), TASK_COOLDOWN))


def _daily_count(user):
    now = _now(); reset = _safe_int(user.get("task_day_started"), 0)
    if not reset or now - reset >= 86400:
        return 0, now
    return _safe_int(user.get("daily_task_count"), 0), reset


async def _verify_telegram_join(bot, user_id, url):
    """Verify Telegram membership for public links and configured private invite links."""
    if not url:
        return False
    parsed = urlparse(str(url).strip())
    if parsed.netloc.lower().replace("www.", "") not in {"t.me", "telegram.me"}:
        return False
    path = parsed.path.strip("/")
    if not path:
        return False

    # Private invite links (t.me/+HASH or t.me/joinchat/HASH) do not expose
    # a chat identifier. Use TASK_PRIVATE_CHAT_ID for the actual channel ID.
    if path.startswith("+") or path.startswith("joinchat/"):
        if not TASK_PRIVATE_CHAT_ID:
            logger.warning("Private Telegram task needs TASK_PRIVATE_CHAT_ID")
            return False
        chat_id = TASK_PRIVATE_CHAT_ID
    else:
        chat_id = "@" + path.split("/")[0].lstrip("@")

    try:
        member = await bot.get_chat_member(chat_id, int(user_id))
        return member.status in {"member", "administrator", "creator"}
    except Exception:
        logger.exception("telegram task verification failed for chat %s", chat_id)
        return False


def _reserve_completion(user_id, task_id):
    doc = {"user_id": int(user_id), "task_id": str(task_id), "status": "pending", "created_at": _now()}
    try:
        completions_collection.insert_one(doc)
        return True, "new"
    except DuplicateKeyError:
        existing = completions_collection.find_one({"user_id": int(user_id), "task_id": str(task_id)})
        if existing and existing.get("status") == "rewarded":
            return False, "already"
        # Never let two concurrent requests both proceed from the same pending record.
        # A stale reservation is recoverable after a short safety window.
        if existing and existing.get("status") == "pending":
            age = _now() - _safe_int(existing.get("created_at"), _now())
            if age < 600:
                return False, "in_progress"
            completions_collection.delete_one({"_id": existing.get("_id"), "status": "pending"})
            try:
                completions_collection.insert_one(doc)
                return True, "new"
            except DuplicateKeyError:
                return False, "in_progress"
        return False, "already"
    except Exception:
        logger.exception("task completion reservation failed")
        return False, "error"


def _vip_manual_review_required(user_id, task):
    # VIP task claims are always admin-reviewed. For a BOTH task, only VIP users are reviewed.
    audience = str(task.get("audience", "normal")).strip().lower()
    return audience == "vip" or (audience == "both" and _is_vip(user_id))


def _manual_reward(user_id, task):
    reward = max(0, _safe_int(task.get("reward"), 0))
    try:
        reward = int(round(reward * max(1.0, float(get_membership_multiplier(user_id)))))
    except Exception:
        pass
    return reward


def request_vip_task_review(user_id, task_id):
    user = get_user(user_id, create=False); task = get_task(task_id)
    if not user or not task or user.get("banned") or user.get("blacklisted") or not task_visible(user_id, task):
        return False, "Unavailable."
    if not _vip_manual_review_required(user_id, task):
        return False, "এই টাস্কটি সাধারণ সদস্যদের জন্য স্বয়ংক্রিয়ভাবে যাচাই হয়।"
    if not task_available(user_id, task_id):
        existing = completions_collection.find_one({"user_id": int(user_id), "task_id": str(task_id)})
        if existing and existing.get("status") == "pending":
            return False, "Your task is already waiting for Admin approval."
        return False, "Task already completed."
    reserved, state = _reserve_completion(user_id, task_id)
    if not reserved:
        return False, "Your task is already waiting for Admin approval." if state == "in_progress" else "Task already completed."
    completions_collection.update_one(
        {"user_id": int(user_id), "task_id": str(task_id)},
        {"$set": {"status": "pending", "submitted_at": _now(), "reward_requested": _manual_reward(user_id, task)}}
    )
    return True, "Pending"


def approve_task_completion(user_id, task_id, admin_id):
    try:
        if int(admin_id) != int(ADMIN_ID):
            return False, "শুধু অ্যাডমিনের জন্য।"
    except Exception:
        return False, "শুধু অ্যাডমিনের জন্য।"
    task = get_task(task_id); user = get_user(user_id, create=False)
    if not task or not user:
        return False, "Task or user not found."
    record = completions_collection.find_one({"user_id": int(user_id), "task_id": str(task_id), "status": "pending"})
    if not record:
        return False, "No pending completion found."
    reward = _manual_reward(user_id, task)
    if reward:
        add_balance(user_id, reward)
    xp = _safe_int(task.get("xp"), 0)
    if xp:
        add_xp(user_id, xp)
    now = _now()
    user = get_user(user_id, create=False) or {}
    history = _completed_map(user); history[str(task_id)] = now
    completed = list({*map(str, user.get("completed_tasks", [])), str(task_id)})
    count, reset = _daily_count(user)
    update_user(user_id, {"task_history": history, "completed_tasks": completed, "daily_task_count": count + 1, "task_day_started": reset})
    completions_collection.update_one({"_id": record["_id"], "status": "pending"}, {"$set": {"status": "rewarded", "reward": reward, "approved_at": now, "approved_by": int(admin_id)}})
    try:
        from referral import activate_referral
        activate_referral(user_id, "task")
    except Exception:
        logger.exception("Referral activation hook failed")
    try: add_activity(user_id, f"VIP task approved: {task.get('title')}", reward)
    except Exception: pass
    try:
        from database import increment_campaign_score
        from config import ACTIVE_CAMPAIGN_TASK_SCORE
        increment_campaign_score(user_id, task_delta=ACTIVE_CAMPAIGN_TASK_SCORE)
    except Exception:
        logger.exception("Active campaign task score update failed")
    return True, f"Approved +{reward} Points"


def reject_task_completion(user_id, task_id, admin_id, reason="Rejected"):
    try:
        if int(admin_id) != int(ADMIN_ID):
            return False, "শুধু অ্যাডমিনের জন্য।"
    except Exception:
        return False, "শুধু অ্যাডমিনের জন্য।"
    record = completions_collection.find_one({"user_id": int(user_id), "task_id": str(task_id), "status": "pending"})
    if not record:
        return False, "No pending completion found."
    completions_collection.update_one({"_id": record["_id"], "status": "pending"}, {"$set": {"status": "rejected", "rejected_at": _now(), "rejected_by": int(admin_id), "reason": str(reason or "Rejected")[:300]}})
    return True, "Rejected"


def complete_task(user_id, task_id, bot=None):
    user = get_user(user_id, create=False); task = get_task(task_id)
    if not user or not task or user.get("banned") or user.get("blacklisted") or not task_visible(user_id, task):
        return False, "Unavailable."
    if not task_available(user_id, task_id):
        return False, "Task already completed."

    if _vip_manual_review_required(user_id, task):
        return request_vip_task_review(user_id, task_id)
    verification = _normalise_verification(task.get("verification_method"), task.get("url"))
    if verification == "telegram_join":
        if bot is None:
            return False, "Verification is temporarily unavailable."
        import asyncio
        try:
            verified = asyncio.get_event_loop().run_until_complete(_verify_telegram_join(bot, user_id, task.get("url")))
        except RuntimeError:
            # Called from an async handler: caller should use complete_task_async.
            return False, "Verification is temporarily unavailable."
        if not verified:
            return False, "Please complete the Telegram join task first."
    elif TASK_VERIFICATION_ENABLED and verification == "manual":
        return False, "এই টাস্কের জন্য অ্যাডমিন/প্রোভাইডার যাচাই প্রয়োজন; এটি স্বয়ংক্রিয়ভাবে যাচাই করা যাবে না।"

    settings = db["bot_settings"].find_one({"_id": "main"}) or {}
    daily_limit = max(1, _safe_int(settings.get("daily_task_limit"), 20))
    count, reset = _daily_count(user)
    if count >= daily_limit:
        return False, "Daily task limit reached."
    energy_cost = max(0, _safe_int(task.get("energy"), 1))
    if energy_cost and not use_energy(user_id, energy_cost):
        return False, "Not enough Energy."
    reserved, state = _reserve_completion(user_id, task_id)
    if not reserved:
        return False, "Task already completed."
    reward = max(0, _safe_int(task.get("reward"), 0))
    try:
        reward = int(round(reward * max(1.0, float(get_membership_multiplier(user_id)))))
    except Exception:
        pass
    history = _completed_map(user); history[str(task_id)] = _now()
    update_user(user_id, {"task_history": history, "completed_tasks": list({*map(str, user.get("completed_tasks", [])), str(task_id)}), "daily_task_count": count + 1, "task_day_started": reset})
    if reward:
        add_balance(user_id, reward)
    if _safe_int(task.get("xp"), 0):
        add_xp(user_id, _safe_int(task.get("xp"), 0))
    completions_collection.update_one({"user_id": int(user_id), "task_id": str(task_id)}, {"$set": {"status": "rewarded", "reward": reward, "completed_at": _now()}})
    try:
        from referral import activate_referral
        activate_referral(user_id, "task")
    except Exception:
        logger.exception("Referral activation hook failed")
    try: add_activity(user_id, f"Task completed: {task.get('title')}", reward)
    except Exception: pass
    try:
        from database import increment_campaign_score
        from config import ACTIVE_CAMPAIGN_TASK_SCORE
        increment_campaign_score(user_id, task_delta=ACTIVE_CAMPAIGN_TASK_SCORE)
    except Exception:
        logger.exception("Active campaign task score update failed")
    return True, "OK"


async def complete_task_async(user_id, task_id, bot):
    user = get_user(user_id, create=False); task = get_task(task_id)
    if not user or not task or user.get("banned") or user.get("blacklisted") or not task_visible(user_id, task):
        return False, "Unavailable."
    if not task_available(user_id, task_id):
        return False, "Task already completed."
    if _vip_manual_review_required(user_id, task):
        return request_vip_task_review(user_id, task_id)
    verification = _normalise_verification(task.get("verification_method"), task.get("url"))
    if verification == "telegram_join" and not await _verify_telegram_join(bot, user_id, task.get("url")):
        return False, "Please complete the Telegram join task first."
    if TASK_VERIFICATION_ENABLED and verification == "manual":
        return False, "এই টাস্কের জন্য অ্যাডমিন/প্রোভাইডার যাচাই প্রয়োজন; এটি স্বয়ংক্রিয়ভাবে যাচাই করা যাবে না।"
    settings = db["bot_settings"].find_one({"_id": "main"}) or {}
    daily_limit = max(1, _safe_int(settings.get("daily_task_limit"), 20))
    count, reset = _daily_count(user)
    if count >= daily_limit: return False, "Daily task limit reached."
    reserved, state = _reserve_completion(user_id, task_id)
    if not reserved:
        return False, "Task already completed." if state == "already" else "Task verification is already in progress. Please try again shortly."
    energy_cost = max(0, _safe_int(task.get("energy"), 1))
    if energy_cost and not use_energy(user_id, energy_cost):
        if state == "new":
            completions_collection.delete_one({"user_id": int(user_id), "task_id": str(task_id), "status": "pending"})
        return False, "Not enough Energy."
    reward = max(0, _safe_int(task.get("reward"), 0))
    try: reward = int(round(reward * max(1.0, float(get_membership_multiplier(user_id)))))
    except Exception: pass
    completed = list({*map(str, user.get("completed_tasks", [])), str(task_id)})
    update_user(user_id, {"task_history": {**_completed_map(user), str(task_id): _now()}, "completed_tasks": completed, "daily_task_count": count + 1, "task_day_started": reset})
    if reward: add_balance(user_id, reward)
    xp = _safe_int(task.get("xp"), 0)
    if xp: add_xp(user_id, xp)
    completions_collection.update_one({"user_id": int(user_id), "task_id": str(task_id)}, {"$set": {"status": "rewarded", "reward": reward, "completed_at": _now()}})
    try:
        from referral import activate_referral; activate_referral(user_id, "task")
    except Exception: logger.exception("Referral activation hook failed")
    try: add_activity(user_id, f"Task completed: {task.get('title')}", reward)
    except Exception: pass
    try:
        from database import increment_campaign_score
        from config import ACTIVE_CAMPAIGN_TASK_SCORE
        increment_campaign_score(user_id, task_delta=ACTIVE_CAMPAIGN_TASK_SCORE)
    except Exception:
        logger.exception("Active campaign task score update failed")
    return True, "OK"


def _offerwall_task_category(task):
    """Classify provider tasks using provider metadata first, then title/text keywords."""
    if not isinstance(task, dict):
        return "other"
    raw = " ".join(str(task.get(k) or "") for k in ("offer_type", "task_type", "type", "category", "vertical", "title", "description", "instructions", "platform")).lower()
    if any(k in raw for k in ("video", "watch ad", "rewarded ad", "reward video", "ad view", "watch video")):
        return "video"
    if any(k in raw for k in ("install", "app install", "download app", "mobile app", "android app", "ios app", "cpi")):
        return "app"
    if any(k in raw for k in ("signup", "sign up", "register", "registration", "create account", "lead", "join", "follow", "like", "subscribe", "visit", "click", "simple task")):
        return "easy"
    if any(k in raw for k in ("survey", "questionnaire", "poll")):
        return "survey"
    return "other"


def _offerwall_task_category_label(category):
    return {
        "easy": "🟢 Easy Tasks",
        "app": "📱 App Install",
        "video": "🎬 Video Ads",
        "survey": "📝 Surveys",
        "other": "💰 Other Tasks",
    }.get(str(category), "💰 Other Tasks")


def _offerwall_category_tasks(user_id, category):
    tasks = _get_offerwall_tasks_cached(user_id)
    return [
        t for t in tasks
        if _offerwall_task_category(t) == category
        and not _provider_task_hidden("offerwallme", user_id, str(t.get("id") or ""))
    ]


def _get_offerwall_tasks_cached(user_id):
    try:
        tasks = get_cached_offerwallme_tasks(int(user_id))
        return list(tasks or [])
    except Exception:
        return []


async def _refresh_tasks_in_background(query, user_id: int):
    key = int(user_id)
    if key in _BACKGROUND_REFRESHING:
        return
    _BACKGROUND_REFRESHING.add(key)
    try:
        await asyncio.to_thread(refresh_offerwallme_tasks, user_id)
        if query and query.message:
            db_user = get_user(user_id, create=False)
            if not db_user or db_user.get("banned") or db_user.get("blacklisted"):
                return
            task_list = get_tasks(user_id=user_id)
            count, _ = _daily_count(db_user)
            settings = db["bot_settings"].find_one({"_id":"main"}) or {}
            limit = max(1, _safe_int(settings.get("daily_task_limit"), 20))
            offerwall_tasks = _get_offerwall_tasks_cached(user_id)
            normal = [t for t in task_list if t.get("audience","normal") in {"normal","both"}]
            vip = [t for t in task_list if t.get("audience","normal") in {"vip","both"}]
            text = "🎯 **টাস্ক সেন্টার**\n\nনিচের তালিকা থেকে টাস্কের ধরন বেছে নিন।"
            await query.edit_message_text(text, reply_markup=tasks_menu(user_id, offerwall_tasks=offerwall_tasks), parse_mode="Markdown")
    except Exception:
        logger.exception("Background task refresh failed | user=%s", user_id)
        if query and query.message:
            try:
                db_user = get_user(user_id, create=False)
                if db_user and not db_user.get("banned") and not db_user.get("blacklisted"):
                    await query.edit_message_text(
                        "🎯 **টাস্ক সেন্টার**\n\n"
                        "এই মুহূর্তে কোনো টাস্ক পাওয়া যাচ্ছে না।\n"
                        "নিচের টাস্কের ধরনগুলো ব্যবহার করতে পারবেন; তালিকা স্বয়ংক্রিয়ভাবে আপডেট হবে।",
                        reply_markup=tasks_menu(user_id),
                        parse_mode="Markdown",
                    )
            except Exception:
                logger.exception("Could not update Task Center after provider refresh failure | user=%s", user_id)
    finally:
        _BACKGROUND_REFRESHING.discard(key)


def tasks_menu(user_id=None, offerwall_tasks=None, offerwall_category=None):
    buttons=[]
    for task in get_tasks(user_id=user_id):
        available = task_available(user_id, task["id"]) if user_id else True
        buttons.append([InlineKeyboardButton(f"{'🎯' if available else '✅'} {_md(task.get('title',''))} (+{_safe_int(task.get('reward'),0)})", callback_data=f"task_{task['id']}")])
    if user_id:
        # Keep the provider areas separate and clean:
        # BD Advance Tasks = CPAlead BD offers
        # Rewards Tasks = Offerwall.me categories (the old task buttons).
        buttons.append([InlineKeyboardButton("🇧🇩 BD টাস্ক", callback_data="cpalead_tasks")])
        buttons.append([InlineKeyboardButton("🎁 রিওয়ার্ড টাস্ক", callback_data="reward_tasks")])
    buttons.append([InlineKeyboardButton("🏠 হোম", callback_data="home")])
    return InlineKeyboardMarkup(buttons)


async def tasks_page(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user; message = update.effective_message
    if not user or not message: return
    db_user=get_user(user.id, create=False)
    if not db_user or db_user.get("banned") or db_user.get("blacklisted"):
        await message.reply_text("🚫 Your account is restricted."); return
    task_list=get_tasks(user_id=user.id); count,_=_daily_count(db_user); settings=db["bot_settings"].find_one({"_id":"main"}) or {}; limit=max(1,_safe_int(settings.get("daily_task_limit"),20))
    # Offerwall.me is opened as its hosted signed placement. This avoids
    # requesting task feeds from Render with the server IP masquerading as the
    # Telegram member's IP; the hosted placement handles PTC and proof flows.
    offerwall_tasks = []
    normal=[t for t in task_list if t.get("audience","normal") in {"normal","both"}]
    vip=[t for t in task_list if t.get("audience","normal") in {"vip","both"}]
    if not task_list and not offerwall_tasks:
        text = (
            "🎯 **টাস্ক সেন্টার**\n\n"
            "এই মুহূর্তে কোনো custom task নেই।\n"
            "Offerwall.me-এর task ও PTC দেখতে নিচের 🎁 রিওয়ার্ড টাস্ক বাটনে চাপ দিন।"
        )
    else:
        text = "🎯 **টাস্ক সেন্টার**\n\nনিচের তালিকা থেকে টাস্কের ধরন বেছে নিন।"
    markup = tasks_menu(user.id, offerwall_tasks=offerwall_tasks)
    if update.callback_query:
        try:
            await update.callback_query.edit_message_text(text, reply_markup=markup, parse_mode="Markdown")
        except Exception:
            await message.reply_text(text, reply_markup=markup, parse_mode="Markdown")
    else:
        await message.reply_text(text, reply_markup=markup, parse_mode="Markdown")


async def task_callback(update, context):
    q=update.callback_query
    if not q or not str(q.data).startswith("task_"): return
    await q.answer(); tid=str(q.data)[5:]; task=get_task(tid)
    if not task or not task_visible(q.from_user.id, task): await q.edit_message_text("⚠️ টাস্কটি পাওয়া যাচ্ছে না বা বর্তমানে বন্ধ আছে।"); return
    buttons=[]
    if task.get("url"): buttons.append([InlineKeyboardButton("🚀 টাস্ক শুরু করুন", url=task["url"])])
    verification = _normalise_verification(task.get("verification_method"), task.get("url"))
    if _vip_manual_review_required(q.from_user.id, task):
        buttons.append([InlineKeyboardButton("📨 অ্যাডমিন যাচাইয়ের জন্য পাঠান", callback_data=f"task_complete_{tid}")])
    elif verification in {"telegram_join", "click_once"}:
        label = "🎁 ১০ Points সংগ্রহ করুন" if verification == "click_once" else "✅ টাস্ক যাচাই করুন"
        buttons.append([InlineKeyboardButton(label, callback_data=f"task_complete_{tid}")])
    buttons.append([InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    audience = str(task.get("audience", "normal")).upper()
    await q.edit_message_text(f"🎯 **{_md(task.get('title',''))}**\n\n{_md(task.get('description',''))}\n\n💰 পুরস্কার: {_safe_int(task.get('reward'),0)} Points\n🏷 সদস্যের ধরন: {_md(audience)}\n🔐 যাচাই পদ্ধতি: {_md(task.get('verification_method','telegram_join'))}", reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def task_complete_callback(update, context):
    q=update.callback_query
    if not q or not str(q.data).startswith("task_complete_"): return
    await q.answer(); tid=str(q.data)[len("task_complete_"):]; task=get_task(tid)
    if not task: await q.edit_message_text("⚠️ টাস্কটি পাওয়া যাচ্ছে না।"); return
    ok,msg=await complete_task_async(q.from_user.id,tid,context.bot)
    if ok and _vip_manual_review_required(q.from_user.id, task):
        text = f"📨 **টাস্ক জমা হয়েছে**\n\n🎯 {_md(task.get('title',''))}\n\nআপনার VIP টাস্কটি অ্যাডমিন যাচাইয়ের জন্য পাঠানো হয়েছে।\n💰 অনুমোদনের পর Points যোগ হবে।"
    else:
        text = f"🎉 **টাস্ক সম্পন্ন হয়েছে!**\n\n🎯 {_md(task.get('title',''))}\n💰 Points সফলভাবে যোগ হয়েছে।" if ok else f"❌ **টাস্ক সম্পন্ন হয়নি**\n\n{msg}"
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ টাস্কসমূহ",callback_data="tasks")],[InlineKeyboardButton("🏠 হোম",callback_data="home")]]), parse_mode="Markdown")


async def cpalead_tasks_callback(update, context):
    q = update.callback_query
    if not q or q.data != "cpalead_tasks":
        return
    await q.answer()
    user_id = int(q.from_user.id)
    offers = list(get_cached_cpa_lead_bd_offers(user_id) or [])
    if not offers:
        try:
            offers = list(await asyncio.to_thread(refresh_cpa_lead_bd_offers, user_id) or [])
        except Exception:
            logger.exception("CPAlead BD task refresh failed | user=%s", user_id)
            offers = []
    lines = ["🇧🇩 **BD টাস্ক**", "", "টাস্কটি সঠিকভাবে সম্পন্ন করুন। প্রোভাইডার যাচাই করার পর Points যোগ হবে।", ""]
    buttons = []
    for offer in offers[:20]:
        oid = str(offer.get("offer_id") or "").strip()
        if not oid or _provider_task_hidden("cpalead", user_id, oid):
            continue
        reward = _cpa_lead_member_reward_points(offer.get("provider_reward", 0), user_id)
        title = str(offer.get("title") or "BD Task").strip()
        buttons.append([InlineKeyboardButton(f"🎯 {title[:30]} (+{reward})", callback_data=f"cpalead_{oid}")])
    if not buttons:
        lines.append("😔 এই মুহূর্তে কোনো BD টাস্ক পাওয়া যাচ্ছে না।")
    buttons.append([InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    await q.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def rewards_tasks_callback(update, context):
    """Open the official Offerwall.me hosted placement with a signed user ID."""
    q = update.callback_query
    if not q or q.data != "reward_tasks":
        return
    await q.answer()
    user_id = int(q.from_user.id)
    wall_url = get_offerwallme_hosted_url(user_id)

    if wall_url:
        text = (
            "🎁 **Offerwall.me Rewards**\n\n"
            "নিচের বাটনে চাপ দিলে Offerwall.me-এর নিরাপদ hosted page খুলবে। "
            "সেখানে উপলভ্য tasks, PTC ads এবং প্রয়োজনীয় proof submission সম্পন্ন করতে পারবেন।\n\n"
            "✅ আপনার Telegram user ID-এর জন্য signed link তৈরি হয়েছে।\n"
            "ℹ️ কাজ ও পুরস্কার Offerwall.me-এর country, device এবং placement inventory-এর ওপর নির্ভর করে।"
        )
        buttons = [[InlineKeyboardButton("🚀 Open Offerwall.me", url=wall_url)]]
    else:
        text = (
            "⚠️ **Offerwall.me সেটআপ অসম্পূর্ণ**\n\n"
            "Render Environment-এ OFFERWALLME_ENABLED=true, OFFERWALLME_API_KEY "
            "এবং OFFERWALLME_POSTBACK_SECRET সঠিকভাবে সেট করুন।"
        )
        buttons = []

    buttons.append([InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def cpalead_task_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("cpalead_") or q.data == "cpalead_tasks":
        return
    await q.answer()
    offer_id = str(q.data)[len("cpalead_"):]
    offers = list(get_cached_cpa_lead_bd_offers(q.from_user.id) or [])
    offer = next((x for x in offers if str(x.get("offer_id")) == offer_id), None)
    if not offer:
        try:
            offers = list(await asyncio.to_thread(refresh_cpa_lead_bd_offers, int(q.from_user.id)) or [])
            offer = next((x for x in offers if str(x.get("offer_id")) == offer_id), None)
        except Exception:
            offer = None
    if not offer:
        await q.edit_message_text("⚠️ এই BD টাস্কটি আর পাওয়া যাচ্ছে না।", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ BD টাস্ক", callback_data="cpalead_tasks")]]))
        return
    if _provider_task_hidden("cpalead", q.from_user.id, offer_id):
        await q.edit_message_text(
            "ℹ️ এই টাস্কটি ইতিমধ্যে শুরু বা সম্পন্ন হয়েছে এবং এখন আর পাওয়া যাবে না।",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ BD টাস্ক", callback_data="cpalead_tasks")]])
        )
        return
    reward = _cpa_lead_member_reward_points(offer.get("provider_reward", 0), q.from_user.id)
    title = str(offer.get("title") or "BD Task")
    description = str(offer.get("description") or "").replace("\n", "\n").strip()
    url = _cpa_lead_offer_url(offer, q.from_user.id)
    _record_provider_pending("cpalead", q.from_user.id, offer_id, title, reward, offer.get("provider_reward", 0))
    text = f"🎯 **{_md(title)}**\n\n"
    if description:
        text += f"{_md(description)}\n\n"
    text += f"💰 পুরস্কার: +{reward} Points\n🇧🇩 ধরন: BD Advance Task\n\n📌 টাস্কটি শুরু করুন এবং পুরো কাজটি সম্পন্ন করুন। প্রোভাইডার যাচাই করার পর Points স্বয়ংক্রিয়ভাবে যোগ হবে।"
    buttons = []
    if url:
        buttons.append([InlineKeyboardButton("🚀 টাস্ক শুরু করুন", url=url)])
    if int(q.from_user.id) == int(ADMIN_ID):
        buttons.append([InlineKeyboardButton("🧪 অ্যাডমিন টেস্ট সম্পন্ন", callback_data=f"admtest_cpa_{offer_id}")])
    buttons.append([InlineKeyboardButton("⬅️ BD টাস্ক", callback_data="cpalead_tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def offerwallme_category_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("owcat_"):
        return
    await q.answer()
    category = str(q.data)[len("owcat_"):]
    allowed = {"easy", "app", "video", "survey", "other"}
    if category not in allowed:
        return
    tasks = _offerwall_category_tasks(q.from_user.id, category)
    label = _offerwall_task_category_label(category)
    lines = [f"{label}", "", "টাস্কটি সঠিকভাবে সম্পন্ন করুন। প্রোভাইডার যাচাই করার পর Points যোগ হবে।", ""]
    buttons = []
    if tasks:
        for task in tasks[:OFFERWALLME_TASK_LIMIT]:
            task_id = str(task.get("id") or "")
            if not task_id:
                continue
            title = str(task.get("title") or "Reward Task")
            reward = _offerwallme_reward_points(task.get("reward", task.get("payout", task.get("amount", 0))), q.from_user.id)
            buttons.append([InlineKeyboardButton(f"🎯 {title[:28]} (+{reward})", callback_data=f"owtask_{task_id}")])
    else:
        lines.append("😔 এই মুহূর্তে এই ধরনের কোনো টাস্ক পাওয়া যাচ্ছে না।")
        if category == "video":
            lines.append("ভিডিও টাস্ক Offerwall.me-এর বর্তমান inventory, দেশ ও device-এর ওপর নির্ভর করে।")
    lines += ["", "টাস্কের তালিকা স্বয়ংক্রিয়ভাবে পরিবর্তন হয়; কোনো টাস্ক সম্পন্ন বা মেয়াদ শেষ হলে সেটি আর দেখা যাবে না।"]
    buttons.append([InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    await q.edit_message_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def offerwallme_task_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("owtask_"):
        return
    await q.answer()
    task_id = str(q.data)[len("owtask_"):]
    try:
        tasks = _get_offerwall_tasks_cached(q.from_user.id)
    except Exception:
        tasks = []
    task = next((t for t in tasks if str(t.get("id")) == task_id), None)
    if not task:
        await q.edit_message_text("⚠️ এই রিওয়ার্ড টাস্কটি আর পাওয়া যাচ্ছে না।", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks")]]))
        return

    if _provider_task_hidden("offerwallme", q.from_user.id, task_id):
        await q.edit_message_text(
            "ℹ️ এই টাস্কটি ইতিমধ্যে শুরু বা সম্পন্ন হয়েছে এবং এখন আর পাওয়া যাবে না।",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks")]])
        )
        return

    # No screenshot/proof step: opening a provider task creates one conversion
    # slot. The actual reward is credited only when Offerwall.me
    # sends a verified postback for this user. Keep only the latest pending
    # task to avoid ambiguous conversion matching.
    try:
        reward_raw = str(task.get("reward", task.get("payout", task.get("amount", 0))) or "0")
        db["offerwall_task_submissions"].update_many(
            {"user_id": int(q.from_user.id), "status": "pending"},
            {"$set": {"status": "abandoned", "abandoned_at": int(time.time())}},
        )
        mark_offerwall_task_submission(
            q.from_user.id, task_id, "pending",
            submitted_at=int(time.time()),
            provider_reward_raw=reward_raw,
            task_title=str(task.get("title") or "")[:200],
            proof_kind="none",
            proof_text="",
        )
        _record_provider_pending(
            "offerwallme", q.from_user.id, task_id, str(task.get("title") or "Reward Task"),
            _offerwallme_reward_points(reward_raw, q.from_user.id), reward_raw
        )
    except Exception:
        logger.exception("Could not create Offerwall.me pending task slot | user=%s task=%s", q.from_user.id, task_id)

    submission = get_offerwall_task_submission(q.from_user.id, task_id)
    submission_status = str((submission or {}).get("status") or "pending").lower()
    reward = _offerwallme_reward_points(task.get("reward", task.get("payout", task.get("amount", 0))), q.from_user.id)

    def _display_text(value):
        return (str(value or "").replace("\\n", "\n").replace("<p>", "").replace("</p>", "").strip())

    instructions = _display_text(task.get("instructions") or task.get("description"))
    context.user_data["offerwallme_task_preview"] = task_id
    context.user_data.pop("offerwallme_pending_task", None)
    text = f"🎯 **{_md(_display_text(task.get('title','Offerwall Task')))}**\n\n"
    description = _display_text(task.get("description"))
    if description:
        text += f"{_md(description)}\n\n"
    if instructions:
        text += f"📋 **নির্দেশনা:**\n{_md(instructions)}\n\n"
    category = _offerwall_task_category(task)
    category_label = _offerwall_task_category_label(category)
    platform = str(task.get("platform") or "").strip()
    text += f"💰 পুরস্কার: +{reward} Points\n🏷 ধরন: {_md(category_label)}"
    if platform:
        text += f"\n📱 Platform: {_md(platform)}"
    text += "\n\n🇧🇩 **কাজটি যেভাবে সম্পূর্ণ করবেন:**\n1️⃣ নিচের **🚀 কাজ শুরু করুন** বাটনে চাপ দিন।\n2️⃣ প্রোভাইডারের দেওয়া কাজটি পুরোপুরি সম্পূর্ণ করুন।\n3️⃣ কাজ শেষ হলে প্রোভাইডার আপনার completion verify করবে।\n4️⃣ Verify হলে আপনার Points স্বয়ংক্রিয়ভাবে যোগ হবে।\n\n⚠️ শুধু বাটনে চাপ দিলেই Points যোগ হবে না।"

    buttons = []
    task_url = _offerwallme_task_tracking_url(str(task.get("url") or task.get("link") or "").strip(), q.from_user.id)
    if task_url and submission_status != "rewarded":
        buttons.append([InlineKeyboardButton("🚀 কাজ শুরু করুন", url=task_url)])
        buttons.append([InlineKeyboardButton("✅ কাজ শেষ করেছি", callback_data=f"owpending_{task_id}")])
    if int(q.from_user.id) == int(ADMIN_ID) and submission_status != "rewarded":
        buttons.append([InlineKeyboardButton("🧪 অ্যাডমিন টেস্ট সম্পন্ন", callback_data=f"admtest_ow_{task_id}")])
    if submission_status == "rewarded":
        text = text.replace("🇧🇩 **কাজটি যেভাবে সম্পূর্ণ করবেন:**\n1️⃣ নিচের **🚀 কাজ শুরু করুন** বাটনে চাপ দিন।\n2️⃣ প্রোভাইডারের দেওয়া কাজটি পুরোপুরি সম্পূর্ণ করুন।\n3️⃣ কাজ শেষ হলে প্রোভাইডার আপনার completion verify করবে।\n4️⃣ Verify হলে আপনার Points স্বয়ংক্রিয়ভাবে যোগ হবে।\n\n⚠️ শুধু বাটনে চাপ দিলেই Points যোগ হবে না।", "🇧🇩 **কাজটি সম্পূর্ণ হয়েছে।**\n\n✅ প্রোভাইডার আপনার কাজ verify করেছে এবং Points যোগ করা হয়েছে।")
        buttons = []
    buttons.append([InlineKeyboardButton("⬅️ টাস্কসমূহ", callback_data="tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")])
    await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")


async def offerwallme_pending_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("owpending_"):
        return
    await q.answer("টাস্কটি Pending হয়েছে। প্রোভাইডারের verification-এর অপেক্ষায় আছে।", show_alert=True)
    task_id = str(q.data)[len("owpending_"):]
    try:
        tasks = _get_offerwall_tasks_cached(q.from_user.id)
        task = next((t for t in tasks if str(t.get("id")) == task_id), None)
        if not task:
            return
        reward = _offerwallme_reward_points(task.get("reward", task.get("payout", task.get("amount", 0))), q.from_user.id)
        title = _md(str(task.get("title") or "রিওয়ার্ড টাস্ক"))
        text = (
            f"🎯 **{title}**\n\n"
            f"💰 পুরস্কার: +{reward} Points\n\n"
            "⏳ **Pending**\n"
            "প্রোভাইডার আপনার কাজ যাচাই করছে। যাচাই সফল হলে Points স্বয়ংক্রিয়ভাবে যোগ হবে।\n\n"
            "⚠️ একই টাস্ক আবার শুরু করার প্রয়োজন নেই।"
        )
        buttons = [[InlineKeyboardButton("⏳ Pending", callback_data=f"owpending_{task_id}")], [InlineKeyboardButton("⬅️ রিওয়ার্ড টাস্ক", callback_data="reward_tasks"), InlineKeyboardButton("🏠 হোম", callback_data="home")]]
        await q.edit_message_text(text, reply_markup=InlineKeyboardMarkup(buttons), parse_mode="Markdown")
    except Exception:
        logger.exception("Could not show Offerwall.me pending state | user=%s task=%s", q.from_user.id, task_id)


async def admin_test_cpalead_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("admtest_cpa_"):
        return
    await q.answer()
    if int(q.from_user.id) != int(ADMIN_ID):
        await q.edit_message_text("⛔ শুধু অ্যাডমিনের জন্য।")
        return
    offer_id = str(q.data)[len("admtest_cpa_"):]
    offers = list(get_cached_cpa_lead_bd_offers(q.from_user.id) or [])
    offer = next((x for x in offers if str(x.get("offer_id")) == offer_id), None)
    if not offer:
        await q.edit_message_text("⚠️ Offer not found.")
        return
    points = _cpa_lead_member_reward_points(offer.get("provider_reward", 0), q.from_user.id)
    result = admin_test_provider_completion("cpalead", q.from_user.id, offer_id, points, str(offer.get("title") or "CPAlead Test"))
    if result.get("ok"):
        await q.edit_message_text(f"🧪 **CPAlead ADMIN TEST**\\n\\n✅ Completed & credited\\n💰 +{points} Points\\n\\nThis test is available only to Admin ID.", parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ BD টাস্ক", callback_data="cpalead_tasks")],[InlineKeyboardButton("🏠 হোম", callback_data="home")]]))
    else:
        msg = "Already tested this offer." if result.get("error") == "already_tested" else f"Test failed: {result.get('error','unknown')}"
        await q.edit_message_text(f"⚠️ {msg}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ BD টাস্ক", callback_data="cpalead_tasks")]]))


async def admin_test_offerwallme_callback(update, context):
    q = update.callback_query
    if not q or not str(q.data).startswith("admtest_ow_"):
        return
    await q.answer()
    if int(q.from_user.id) != int(ADMIN_ID):
        await q.edit_message_text("⛔ শুধু অ্যাডমিনের জন্য।")
        return
    task_id = str(q.data)[len("admtest_ow_"):]
    tasks = _get_offerwall_tasks_cached(q.from_user.id)
    task = next((t for t in tasks if str(t.get("id")) == task_id), None)
    if not task:
        await q.edit_message_text("⚠️ টাস্কটি পাওয়া যাচ্ছে না।")
        return
    reward_raw = task.get("reward", task.get("payout", task.get("amount", 0)))
    points = _offerwallme_reward_points(reward_raw, q.from_user.id)
    result = admin_test_provider_completion("offerwallme", q.from_user.id, task_id, points, str(task.get("title") or "Offerwall.me Test"))
    if result.get("ok"):
        try:
            mark_offerwall_task_submission(q.from_user.id, task_id, "rewarded", submitted_at=int(time.time()), provider_reward_raw=str(reward_raw), task_title=str(task.get("title") or "")[:200], proof_kind="admin_test", proof_text="admin")
        except Exception:
            logger.exception("Could not mark Offerwall.me admin test submission")
        await q.edit_message_text(f"🧪 **Offerwall.me ADMIN TEST**\\n\\n✅ Completed & credited\\n💰 +{points} Points\\n\\nThis test is available only to Admin ID.", parse_mode="Markdown", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ রিওয়ার্ড টাস্ক", callback_data="reward_tasks")],[InlineKeyboardButton("🏠 হোম", callback_data="home")]]))
    else:
        msg = "Already tested this task." if result.get("error") == "already_tested" else f"Test failed: {result.get('error','unknown')}"
        await q.edit_message_text(f"⚠️ {msg}", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ রিওয়ার্ড টাস্ক", callback_data="reward_tasks")]]))


async def offerwallme_task_proof_callback(update, context):
    q = update.callback_query
    if q:
        await q.answer("Proof is not required. Just complete the task; verified rewards are automatic.", show_alert=True)


async def offerwallme_proof_message_handler(update, context):
    # Offerwall.me provider tasks no longer require user-submitted screenshots/proof.
    return False


HANDLER_FUNCTIONS={"tasks":tasks_page,"task_callback":task_callback,"task_complete_callback":task_complete_callback,"rewards_tasks_callback":rewards_tasks_callback,"cpalead_tasks_callback":cpalead_tasks_callback,"cpalead_task_callback":cpalead_task_callback,"offerwallme_category_callback":offerwallme_category_callback,"offerwallme_task_callback":offerwallme_task_callback,"offerwallme_pending_callback":offerwallme_pending_callback,"offerwallme_task_proof_callback":offerwallme_task_proof_callback,"admin_test_cpalead_callback":admin_test_cpalead_callback,"admin_test_offerwallme_callback":admin_test_offerwallme_callback}
__all__=["register_task","get_tasks","get_task","set_task_enabled","delete_task","task_available","complete_task","complete_task_async","request_vip_task_review","approve_task_completion","reject_task_completion","tasks_menu","tasks_page","task_callback","task_complete_callback","rewards_tasks_callback","cpalead_tasks_callback","cpalead_task_callback","offerwallme_category_callback","offerwallme_task_callback","offerwallme_pending_callback","offerwallme_task_proof_callback","admin_test_cpalead_callback","admin_test_offerwallme_callback","offerwallme_proof_message_handler","HANDLER_FUNCTIONS","ensure_task_indexes"]
